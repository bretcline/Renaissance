$loc = (Get-Date).AddDays(-1).ToString('ddMMyyyy') + '.jnl' 

Get-ChildItem C:\SourceRootFolder -Recurse -Filter $loc | Copy-Item -destination C:\DestinationFolder
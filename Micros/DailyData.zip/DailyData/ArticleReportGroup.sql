
SELECT LIST( name, '|' ORDER BY column_number ) 
FROM sa_describe_query('
SELECT 
      mi.Obj_num    AS ArticleObj
    , mi.name_1     AS ArticleName1
    , mi.name_2     AS ArticleName2
    , maj.obj       AS MajObj
    , maj.name_1    AS MajName
    , fam.obj       AS FamObj
    , fam.name_1    AS FamName
    , typ.obj_num   AS TypeObj
    , typ.name      AS TypeName
FROM micros.mi_def mi
    left outer join micros.v_maj_grp_def maj with(Nolock) on maj.seq = mi.maj_grp_seq
    left outer join micros.v_fam_grp_def fam with(Nolock) on fam.seq = mi.fam_grp_seq
    LEFT JOIN micros.mi_type_class_def typ with(noLock) ON mi.mi_type_seq = typ.mi_type_seq
where 1 = 1 
order by mi.Obj_num
' );
OUTPUT TO 'd:\\DailyData\\ItemData.txt' 
    FORMAT TEXT
    ENCODING 'UTF-8'
    DELIMITED BY '|'
    QUOTE '';

SELECT 
      mi.Obj_num    AS ArticleObj
    , mi.name_1     AS ArticleName1
    , mi.name_2     AS ArticleName2
    , maj.obj       AS MajObj
    , maj.name_1    AS MajName
    , fam.obj       AS FamObj
    , fam.name_1    AS FamName
    , typ.obj_num   AS TypeObj
    , typ.name      AS TypeName
FROM micros.mi_def mi
    left outer join micros.v_maj_grp_def maj with(Nolock) on maj.seq = mi.maj_grp_seq
    left outer join micros.v_fam_grp_def fam with(Nolock) on fam.seq = mi.fam_grp_seq
    LEFT JOIN micros.mi_type_class_def typ with(noLock) ON mi.mi_type_seq = typ.mi_type_seq
where 1 = 1 
order by mi.Obj_num;

OUTPUT TO 'd:\\DailyData\\ItemData.txt'  APPEND
    FORMAT TEXT
    ENCODING 'UTF-8'
    DELIMITED BY '|'
    QUOTE '';
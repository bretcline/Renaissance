
SELECT LIST( name, '|' ORDER BY column_number ) 
FROM sa_describe_query('SELECT cd.Chk_num	AS CheckNumber	
    , dtl.chk_seq							as CheckSequence
    , trans.end_date_tm						as TicketDate
    , dtl.trans_seq							as TransactionID 
    , dtl.dtl_seq 							as DetailSequence
    , mi.name_1								as ItemDescription
    , mi.name_2								as ItemDescriptionCont
    , dtl.Seat								as SeatNumber	
    , dtl.chk_cnt							as GuestCount	
    , dtl.chk_ttl							as TicketTotal
    , dtl.inclusive_tax_ttl					as Tax		
    , cd.sub_ttl							as SubTotal		
    , cd.amt_due_ttl						as AmountDue	
    , empDef.obj_num						as ServerNumber
    , empDef.Long_First_Name				as ServerFirstName
    , empDef.Long_Last_Name					as ServerLastName	
    , empDef.chk_name						as ServerCheckName
    , Maj.name_1 							as Department
    , Fam.name_1 							as Category	
FROM micros.v_dtl dtl with(nolock)			
   left outer join micros.chk_dtl cd with(Nolock) on cd.chk_seq = dtl.chk_seq
   left outer join micros.emp_def empDef with(Nolock) on empDef.Emp_Seq = cd.Emp_Seq
   left outer join micros.mi_def mi on mi.mi_seq=M_mi_Seq
   left outer join micros.v_maj_grp_def maj on maj.seq = mi.maj_grp_seq
   left outer join micros.v_fam_grp_def fam on fam.seq = mi.fam_grp_seq
   left outer join MICROS.trans_dtl TRANS on TRANS.trans_seq = DTL.trans_seq
where 1 = 1
	--AND trans.end_date_tm >= DATEADD( hh, 3, convert(datetime, substring(convert(varchar, dateadd(day, -1, getdate()), 20), 1, 11)))
	AND trans.end_date_tm <  DATEADD( hh, 3, convert(datetime, substring(convert(varchar, dateadd(day, 0, getdate()), 20), 1, 11))) 
order by trans.end_date_tm DESC, dtl.chk_seq, dtl.trans_seq, dtl.dtl_seq, cd.Chk_num;');

OUTPUT TO 'd:\\DailyData\\DailyExport.csv' 
    FORMAT TEXT
    ENCODING 'UTF-8'
    DELIMITED BY '|'
    
    QUOTE '';

SELECT cd.Chk_num
    , dtl.chk_seq
    , trans.end_date_tm
    , dtl.trans_seq
    , dtl.dtl_seq 
    , mi.name_1 AS ItemName
    , mi.name_2 AS ItemName2
    , coalesce(dtl.Seat,0) as Seat
    , coalesce(dtl.chk_cnt, 0) as chk_cnt
    , coalesce(dtl.chk_ttl, 0.00) as chk_ttl
    , dtl.inclusive_tax_ttl
    , cd.sub_ttl
    , cd.amt_due_ttl
    , empDef.obj_num
    , empDef.Long_First_Name
    , empDef.Long_Last_Name
    , empDef.chk_name
    , Maj.name_1 as Department 
    , Fam.name_1 as Category
FROM micros.v_dtl dtl with(nolock)
   left outer join micros.chk_dtl cd with(Nolock) on cd.chk_seq = dtl.chk_seq
   left outer join micros.emp_def empDef with(Nolock) on empDef.Emp_Seq = cd.Emp_Seq
   left outer join micros.mi_def mi on mi.mi_seq=M_mi_Seq
   left outer join micros.v_maj_grp_def maj on maj.seq = mi.maj_grp_seq
   left outer join micros.v_fam_grp_def fam on fam.seq = mi.fam_grp_seq
   left outer join MICROS.trans_dtl TRANS on TRANS.trans_seq = DTL.trans_seq
where dtl.dtl_type in ('M','D')
	AND trans.end_date_tm >= DATEADD( hh, 3, convert(datetime, substring(convert(varchar, dateadd(day, -1, getdate()), 20), 1, 11)))
	AND trans.end_date_tm <  DATEADD( hh, 3, convert(datetime, substring(convert(varchar, dateadd(day, 0, getdate()), 20), 1, 11))) 
order by trans.end_date_tm DESC, dtl.chk_seq, dtl.trans_seq, dtl.dtl_seq, cd.Chk_num;

OUTPUT TO 'd:\\DailyData\\DailyExport.csv' APPEND
    FORMAT TEXT
    ENCODING 'UTF-8'
    DELIMITED BY '|'
    
    QUOTE '';

